import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { IncidentsBySeverity } from '../dtos/schemas/incidents-by-severity.dto';

@Injectable()
export class IncidentsCountSeveritiesService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getAllIncidents(): Observable<IncidentsBySeverity[]> {
		return this.geneseService.getGeneseInstance(IncidentsBySeverity).getAllCustom('/incidents/count/severities') as any;
	}


}
