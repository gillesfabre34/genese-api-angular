import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { Incident } from '../dtos/schemas/incident.dto';

@Injectable()
export class IncidentsIncident_idService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getOneIncidents(): Observable<Incident> {
		return this.geneseService.getGeneseInstance(Incident).getOneCustom('/incidents/{incident_id}') as any;
	}


}
