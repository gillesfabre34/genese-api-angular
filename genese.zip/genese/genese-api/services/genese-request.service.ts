import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GeneseEnvironmentService } from 'genese-angular';











@Injectable()
export class GeneseRequestService {

constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		) {
		this.init();
	}
public getAllIncidents: () => Observable<IncidentsBySeverity[]>;




	init(): void {

		this.getAllIncidents = this.incidentsService.getAllIncidents;
		this.getOneIncidents = this.incidentsIncident_idService.getOneIncidents;
		this. = this.testService.;
		this.getAllReactions = this.reactionsService.getAllReactions;
		this.getOneIam = this.iamUsersUserUser_idService.getOneIam;
		this.getAllIam = this.iamProfilesService.getAllIam;
		this.getOneIam = this.iamProfilesProfile_idService.getOneIam;
		this.getOneIam = this.iamPolicyService.getOneIam;
		this.getOneDashboard = this.dashboardService.getOneDashboard;
		this.getAllIncidents = this.incidentsCountSeveritiesService.getAllIncidents;
	}


}
