import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { Profile } from '../dtos/schemas/profile.dto';

@Injectable()
export class IamProfilesProfile_idService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getOneIam(): Observable<Profile> {
		return this.geneseService.getGeneseInstance(Profile).getOneCustom('/iam/profiles/{profile_id}') as any;
	}


}
