import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { Policy } from '../dtos/schemas/policy.dto';

@Injectable()
export class IamPolicyService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getOneIam(): Observable<Policy> {
		return this.geneseService.getGeneseInstance(Policy).getOneCustom('/iam/policy') as any;
	}


}
