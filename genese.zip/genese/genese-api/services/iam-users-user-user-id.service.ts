import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { User } from '../dtos/schemas/user.dto';

@Injectable()
export class IamUsersUserUser_idService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getOneIam(): Observable<User> {
		return this.geneseService.getGeneseInstance(User).getOneCustom('/iam/users/user/{user_id}') as any;
	}


}
