import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { Profile } from '../dtos/schemas/profile.dto';

@Injectable()
export class IamProfilesService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getAllIam(): Observable<Profile[]> {
		return this.geneseService.getGeneseInstance(Profile).getAllCustom('/iam/profiles') as any;
	}


}
