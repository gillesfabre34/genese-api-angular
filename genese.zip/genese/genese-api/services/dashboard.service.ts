import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { Dashboard } from '../dtos/schemas/dashboard.dto';

@Injectable()
export class DashboardService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getOneDashboard(): Observable<Dashboard> {
		return this.geneseService.getGeneseInstance(Dashboard).getOneCustom('/dashboard') as any;
	}


}
