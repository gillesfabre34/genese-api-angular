import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Genese, GeneseEnvironmentService, GeneseService } from 'genese-angular';
import { Reaction } from '../dtos/schemas/reaction.dto';

@Injectable()
export class ReactionsService {




	constructor(
		private http: HttpClient,
		private geneseEnvironmentService: GeneseEnvironmentService,
		private geneseService: GeneseService,
		) {
		}




	getAllReactions(): Observable<Reaction[]> {
		return this.geneseService.getGeneseInstance(Reaction).getAllCustom('/reactions') as any;
	}


}
