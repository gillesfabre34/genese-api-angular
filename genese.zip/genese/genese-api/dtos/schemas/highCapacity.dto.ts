import { Capacity } from './capacity.dto';

export class HighCapacity {

	public name ?= '';
	public capacities ?= [new Capacity()];
	public icon ?= '';

}