
export class IncidentsBySeverity {

	public count ?= 0;
	public severity ?= '';

}