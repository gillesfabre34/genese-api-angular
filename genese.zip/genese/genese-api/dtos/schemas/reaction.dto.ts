import { Step } from './step.dto';

export class Reaction {

	public reaction_id ?= '';
	public name ?= '';
	public description ?= '';
	public status ?= '';
	public steps ?= [new Step()];

}