
export class UserPost {

	public firstname ?= '';
	public lastname ?= '';
	public user_id ?= '';
	public profiles_id ?= [''];
	public locked ?= false;

}