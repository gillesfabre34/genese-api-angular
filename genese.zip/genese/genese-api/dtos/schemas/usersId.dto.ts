
export class UsersId {

	public users_id ?= [''];

}