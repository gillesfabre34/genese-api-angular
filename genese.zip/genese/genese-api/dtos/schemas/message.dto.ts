
export class Message {

	public message ?= '';

}