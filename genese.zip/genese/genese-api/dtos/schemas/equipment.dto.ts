
export class Equipment {

	public id ?= '';
	public id_capacity ?= '';
	public name ?= '';

}