
export class Profile {

	public profile_id ?= '';
	public description ?= '';
	public users_id ?= [''];

}