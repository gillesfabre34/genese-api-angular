import { DashboardIndicators } from './dashboardindicators.dto';

export class HC {

	public high_capacities ?= new DashboardIndicators();

}