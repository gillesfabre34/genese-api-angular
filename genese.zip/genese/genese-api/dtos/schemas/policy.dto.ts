
export class Policy {

	public password_min_age ?= 0;
	public password_max_age ?= 0;
	public password_min_length ?= 0;
	public password_history ?= 0;
	public password_max_failure ?= 0;

}