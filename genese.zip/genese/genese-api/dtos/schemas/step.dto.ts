
export class Step {

	public step_id ?= '';
	public status ?= '';
	public name ?= '';
	public mandatory ?= false;
	public description ?= '';
	public content ?= '';
	public comment ?= '';

}