
export class IncidentValidation {

	public incident_id ?= '';
	public status ?= '';
	public comments ?= '';

}