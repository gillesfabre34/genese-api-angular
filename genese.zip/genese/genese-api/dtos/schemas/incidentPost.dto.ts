
export class IncidentPost {

	public description ?= '';
	public severity ?= '';
	public title ?= '';
	public comment ?= '';
	public src ?= '';
	public dest ?= '';

}