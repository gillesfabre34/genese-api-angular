
export class DashboardIndicators {

	public attack ?= '';
	public number_of_incidents ?= 0;
	public name ?= '';

}