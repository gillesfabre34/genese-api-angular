
export class Incident {

	public incident_id ?= '';
	public incident_siem_id ?= '';
	public comments ?= [''];
	public reaction_exists ?= '';
	public completion ?= '';
	public count ?= '';
	public create_time ?= '';
	public description ?= '';
	public last_modification_time ?= '';
	public severity ?= '';
	public siem_incident_uri ?= '';
	public status ?= '';
	public title ?= '';
	public sensor ?= '';
	public source ?= '';
	public target ?= '';

}