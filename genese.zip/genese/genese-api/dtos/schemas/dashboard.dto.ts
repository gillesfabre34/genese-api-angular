import { DashboardIndicators } from './dashboardindicators.dto';
import { DashboardIndicators } from './dashboardindicators.dto';

export class Dashboard {

	public high_capacities ?= [new DashboardIndicators()];
	public capacities ?= [new DashboardIndicators()];

}