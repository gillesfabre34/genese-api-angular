
export class Subsystem {

	public id ?= '';
	public id_capacity ?= '';
	public name ?= '';

}