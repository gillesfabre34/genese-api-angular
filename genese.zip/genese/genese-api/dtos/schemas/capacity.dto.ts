
export class Capacity {

	public icon ?= '';
	public name ?= '';
	public attack ?= '';
	public number_incidents ?= 0;

}